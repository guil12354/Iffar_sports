<section class="home">

    <div class="container py-5">

        <!-- ========================================================
             CABEÇALHO DA SEÇÃO
             ======================================================== -->

        <div class="cabecalho-secao mb-4">

            <div>

                <span class="mini-titulo">
                    IFFAR SPORTS
                </span>

                <h1>
                    Últimas notícias
                </h1>

            </div>

            <a
                href="index.php?id=noticias"
                class="link-ver-todas"
            >
                Ver todas
                <i class="bi bi-arrow-right"></i>
            </a>

        </div>


        <?php

        /*
        |--------------------------------------------------------------------------
        | Dados temporários
        |--------------------------------------------------------------------------
        | Posteriormente substituiremos isso pela consulta à tabela de notícias.
        */

        $noticias = [

            [
                'data' => '26/06/2026',
                'titulo' => 'IFFar Uruguaiana',
                'categoria' => 'Institucional',
                'imagem' => 'img/campus-uruguaiana.jpg',
                'link' => '#'
            ],

            [
                'data' => '26/06/2026',
                'titulo' => 'IFFar Sports',
                'categoria' => 'Esportes',
                'imagem' => 'img/campus-uruguaiana.jpg',
                'link' => '#'
            ],

            [
                'data' => '26/06/2026',
                'titulo' => 'Competições movimentam o Campus',
                'categoria' => 'Notícias',
                'imagem' => 'img/campus-uruguaiana.jpg',
                'link' => '#'
            ]

        ];

        ?>


        <!-- ========================================================
             DESTAQUES - DESKTOP
             ======================================================== -->

        <div
            id="carouselNoticiasDesktop"
            class="carousel slide carousel-noticias d-none d-md-block"
        >

            <div class="carousel-inner">

                <div class="carousel-item active">

                    <div class="row g-4 align-items-stretch">


                        <!-- NOTÍCIA PRINCIPAL -->

                        <div class="col-lg-7">

                            <a
                                href="<?= $noticias[0]['link'] ?>"
                                class="noticia-card noticia-destaque"
                            >

                                <img
                                    src="<?= $noticias[0]['imagem'] ?>"
                                    alt="<?= htmlspecialchars($noticias[0]['titulo']) ?>"
                                >

                                <div class="noticia-overlay">

                                    <span class="noticia-categoria">
                                        <?= $noticias[0]['categoria'] ?>
                                    </span>

                                    <div class="noticia-data">
                                        <?= $noticias[0]['data'] ?>
                                    </div>

                                    <h2>
                                        <?= $noticias[0]['titulo'] ?>
                                    </h2>

                                </div>

                            </a>

                        </div>


                        <!-- NOTÍCIAS SECUNDÁRIAS -->

                        <div class="col-lg-5">

                            <div class="row g-4 h-100">

                                <?php for ($i = 1; $i <= 2; $i++): ?>

                                    <div class="col-12">

                                        <a
                                            href="<?= $noticias[$i]['link'] ?>"
                                            class="noticia-card noticia-secundaria"
                                        >

                                            <img
                                                src="<?= $noticias[$i]['imagem'] ?>"
                                                alt="<?= htmlspecialchars($noticias[$i]['titulo']) ?>"
                                            >

                                            <div class="noticia-overlay">

                                                <span class="noticia-categoria">
                                                    <?= $noticias[$i]['categoria'] ?>
                                                </span>

                                                <div class="noticia-data">
                                                    <?= $noticias[$i]['data'] ?>
                                                </div>

                                                <h3>
                                                    <?= $noticias[$i]['titulo'] ?>
                                                </h3>

                                            </div>

                                        </a>

                                    </div>

                                <?php endfor; ?>

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <button
                class="carousel-control-prev controle-noticias"
                type="button"
                data-bs-target="#carouselNoticiasDesktop"
                data-bs-slide="prev"
            >

                <span class="controle-circulo">
                    <i class="bi bi-chevron-left"></i>
                </span>

                <span class="visually-hidden">
                    Anterior
                </span>

            </button>


            <button
                class="carousel-control-next controle-noticias"
                type="button"
                data-bs-target="#carouselNoticiasDesktop"
                data-bs-slide="next"
            >

                <span class="controle-circulo">
                    <i class="bi bi-chevron-right"></i>
                </span>

                <span class="visually-hidden">
                    Próxima
                </span>

            </button>

        </div>



        <!-- ========================================================
             CARROSSEL MOBILE
             ======================================================== -->

        <div
            id="carouselNoticiasMobile"
            class="carousel slide d-md-none"
            data-bs-ride="carousel"
        >

            <div class="carousel-indicators">

                <?php foreach ($noticias as $indice => $noticia): ?>

                    <button
                        type="button"
                        data-bs-target="#carouselNoticiasMobile"
                        data-bs-slide-to="<?= $indice ?>"
                        class="<?= $indice === 0 ? 'active' : '' ?>"
                        aria-label="Notícia <?= $indice + 1 ?>"
                    ></button>

                <?php endforeach; ?>

            </div>


            <div class="carousel-inner">

                <?php foreach ($noticias as $indice => $noticia): ?>

                    <div class="carousel-item <?= $indice === 0 ? 'active' : '' ?>">

                        <a
                            href="<?= $noticia['link'] ?>"
                            class="noticia-card noticia-mobile"
                        >

                            <img
                                src="<?= $noticia['imagem'] ?>"
                                alt="<?= htmlspecialchars($noticia['titulo']) ?>"
                            >

                            <div class="noticia-overlay">

                                <span class="noticia-categoria">
                                    <?= $noticia['categoria'] ?>
                                </span>

                                <div class="noticia-data">
                                    <?= $noticia['data'] ?>
                                </div>

                                <h2>
                                    <?= $noticia['titulo'] ?>
                                </h2>

                            </div>

                        </a>

                    </div>

                <?php endforeach; ?>

            </div>


            <button
                class="carousel-control-prev"
                type="button"
                data-bs-target="#carouselNoticiasMobile"
                data-bs-slide="prev"
            >
                <span class="carousel-control-prev-icon"></span>
            </button>


            <button
                class="carousel-control-next"
                type="button"
                data-bs-target="#carouselNoticiasMobile"
                data-bs-slide="next"
            >
                <span class="carousel-control-next-icon"></span>
            </button>

        </div>

    </div>

</section>