<?php

/*
|--------------------------------------------------------------------------
| NOTÍCIA
|--------------------------------------------------------------------------
| Página individual de uma notícia.
|
| Exemplo:
| index.php?id=noticia&noticiaid=12
|--------------------------------------------------------------------------
*/


/*
|--------------------------------------------------------------------------
| Recupera e valida o ID recebido pela URL
|--------------------------------------------------------------------------
*/

$noticiaId = filter_input(
    INPUT_GET,
    'noticiaid',
    FILTER_VALIDATE_INT
);


/*
|--------------------------------------------------------------------------
| Caso o ID não seja válido
|--------------------------------------------------------------------------
*/

if (!$noticiaId) {
?>

    <section class="container py-5">

        <div class="estado-vazio">

            <i class="bi bi-exclamation-circle"></i>

            <h2>
                Notícia não informada
            </h2>

            <p>
                Não foi possível identificar a notícia solicitada.
            </p>

            <a
                href="index.php?id=noticias"
                class="btn btn-voltar"
            >
                <i class="bi bi-arrow-left"></i>
                Voltar para notícias
            </a>

        </div>

    </section>

<?php

    return;
}


/*
|--------------------------------------------------------------------------
| Busca a notícia no banco
|--------------------------------------------------------------------------
*/

$sqlNoticia = "
    SELECT *
    FROM noticias
    WHERE id_noticia = ?
    LIMIT 1
";

$stmt = $conexao->prepare($sqlNoticia);

$stmt->bind_param(
    "i",
    $noticiaId
);

$stmt->execute();

$resultadoNoticia = $stmt->get_result();


/*
|--------------------------------------------------------------------------
| Caso a notícia não exista
|--------------------------------------------------------------------------
*/

if ($resultadoNoticia->num_rows === 0) {
?>

    <section class="container py-5">

        <div class="estado-vazio">

            <i class="bi bi-newspaper"></i>

            <h2>
                Notícia não encontrada
            </h2>

            <p>
                Essa notícia não existe ou não está mais disponível.
            </p>

            <a
                href="index.php?id=noticias"
                class="btn btn-voltar"
            >
                <i class="bi bi-arrow-left"></i>
                Voltar para notícias
            </a>

        </div>

    </section>

<?php

    return;
}


$noticia = $resultadoNoticia->fetch_assoc();


/*
|--------------------------------------------------------------------------
| Formatação da data
|--------------------------------------------------------------------------
*/

$dataFormatada = '';

if (!empty($noticia['data_noticia'])) {

    $data = strtotime($noticia['data_noticia']);

    if ($data) {
        $dataFormatada = date('d/m/Y', $data);
    }

}

?>


<section class="pagina-noticia">

    <div class="container py-4 py-md-5">

        <article class="noticia-completa">


            <!-- ====================================================
                 VOLTAR
                 ==================================================== -->

            <a
                href="index.php?id=noticias"
                class="voltar-noticias"
            >
                <i class="bi bi-arrow-left"></i>
                Voltar para notícias
            </a>



            <!-- ====================================================
                 CABEÇALHO DA NOTÍCIA
                 ==================================================== -->

            <header class="cabecalho-noticia-completa">

                <span class="mini-titulo">
                    IFFAR SPORTS
                </span>


                <h1>
                    <?= htmlspecialchars($noticia['titulo']) ?>
                </h1>


                <?php if (!empty($noticia['subtitulo'])): ?>

                    <p class="subtitulo-noticia-completa">
                        <?= htmlspecialchars($noticia['subtitulo']) ?>
                    </p>

                <?php endif; ?>


                <div class="meta-noticia">

                    <?php if ($dataFormatada !== ''): ?>

                        <span>

                            <i class="bi bi-calendar3"></i>

                            <?= $dataFormatada ?>

                        </span>

                    <?php endif; ?>


                    <?php if (!empty($noticia['autor'])): ?>

                        <span>

                            <i class="bi bi-person"></i>

                            <?= htmlspecialchars($noticia['autor']) ?>

                        </span>

                    <?php endif; ?>

                </div>

            </header>



            <!-- ====================================================
                 IMAGEM PRINCIPAL
                 ==================================================== -->

            <?php if (!empty($noticia['imagem'])): ?>

                <figure class="imagem-principal-noticia">

                    <img
                        src="<?= htmlspecialchars($noticia['imagem']) ?>"
                        alt="<?= htmlspecialchars($noticia['titulo']) ?>"
                    >

                </figure>

            <?php endif; ?>



            <!-- ====================================================
                 CORPO DA NOTÍCIA
                 ==================================================== -->

            <div class="corpo-noticia">

                <?php

                /*
                |--------------------------------------------------------------------------
                | IMPORTANTE
                |--------------------------------------------------------------------------
                | Aqui NÃO usamos htmlspecialchars(), porque imaginamos que o campo
                | "texto" possa conter HTML criado pelo editor da notícia:
                |
                | <p>...</p>
                | <strong>...</strong>
                | <img ...>
                | <h2>...</h2>
                |
                | Isso permite inserir imagens ao longo do texto.
                |
                | Porém, esse HTML deve vir de um painel administrativo controlado.
                |--------------------------------------------------------------------------
                */

                echo $noticia['texto'];

                ?>

            </div>



            <!-- ====================================================
                 FINAL DA MATÉRIA
                 ==================================================== -->

            <footer class="fim-noticia">

                <div class="linha-fim-noticia"></div>

                <a
                    href="index.php?id=noticias"
                    class="link-voltar-noticias"
                >
                    <i class="bi bi-arrow-left"></i>
                    Ver todas as notícias
                </a>

            </footer>


        </article>

    </div>

</section>